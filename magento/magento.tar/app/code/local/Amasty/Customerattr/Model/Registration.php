<?php
/**
* @author Amasty Team
* @copyright Copyright (c) 2008-2013 Amasty (http://www.amasty.com)
* @package Amasty_Customerattr
*/ 
class Amasty_Customerattr_Model_Registration
{
    public function setAttributeValue($observer)
    {
        /*$model = $observer->getModel();
        $id = $model->getId();
        
        $attribute = 60400000000 + $id;
        $attribute = '0' . $attribute;
        
        $model->setCustIdWr($attribute);
        $model->save();*/
    }
}
